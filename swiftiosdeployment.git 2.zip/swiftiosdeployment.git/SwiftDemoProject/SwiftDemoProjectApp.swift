//
//  SwiftDemoProjectApp.swift
//  SwiftDemoProject
//
//  Created by KARTHI on 19/06/25.
//

import SwiftUI

@main
struct SwiftDemoProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
