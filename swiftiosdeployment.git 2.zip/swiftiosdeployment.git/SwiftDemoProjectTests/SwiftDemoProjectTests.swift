//
//  SwiftDemoProjectTests.swift
//  SwiftDemoProjectTests
//
//  Created by KARTHI on 19/06/25.
//

import Testing

struct SwiftDemoProjectTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
